package pl.edu.pwr.gymplanserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymPlanServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymPlanServerApplication.class, args);
	}

}
