package pl.edu.pwr.gymplanserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymPlanServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
